extends CharacterBody2D

@export var speed := 200.0 # vitesse de déplacement de la raquette 

func _physics_process(delta): # Godot appelle cette fonction en boucle pour mettre à jour le mouvement
	var direction = 0.0 # variable de direction vertical, 0.0 = immobile

	if Input.is_physical_key_pressed(KEY_Z): # vérifie que la touche Z est maintenue 
		direction -= 1 # si oui direction = -1 = sens de direction monté
	if Input.is_physical_key_pressed(KEY_S): # vérifie que la touche S est maintenue 
		direction += 1 # si oui direction = 1 = sens de direction descendre 

	velocity = Vector2(0, direction) * speed # calcule de la vitesse et transforme la direction en mouvement 

	move_and_slide() # applique le mouvement et les colision
