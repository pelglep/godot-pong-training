extends CharacterBody2D

@export var speed := 200.0 # vitesse de déplcament de la raquette 

func _physics_process(delta): # Godot appelle cette fonction en boucle pour mettre à jour le mouvement
	var direction = 0.0 # direction verticale de la raquette, 0 = immoblie 

	if Input.is_physical_key_pressed(KEY_UP): # vérifie que la touche flêche du haut est maintenue
		direction -= 1 # si oui direction = -1 = sens de direction monté
	if Input.is_physical_key_pressed(KEY_DOWN): # vérifie que la touche flêche du bas est maintenue
		direction += 1 # si oui direction = 1 = sens de direction descendre

	velocity = Vector2(0, direction) * speed # carlcule de la vitesse et transforme la direction en mouvement

	move_and_slide() # applique le mouvement et les collision
