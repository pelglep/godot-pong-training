extends Node2D

@onready var ball = $ball
@onready var scoreDroit = $UI/ScoreDroit
@onready var scoreGauche = $UI/ScoreGauche
@onready var messageVictoire = $UI/MessageVictoire
@onready var paddleGauche = $"paddle  gauche"
@onready var paddleDroit = $"paddle droite"
var score_gauche = 0
var score_droit = 0

func _physics_process(delta):

	if ball.position.x < 0 :
		paddleDroit.position = Vector2(620.0, 325)
		paddleGauche.position = Vector2(30.0, 325.0)
		ball.position = Vector2(325.0, 325.0)
		ball.direction = Vector2(-1, 1)
		score_droit += 1
		scoreDroit.text = str(score_droit)
		if score_droit == 5:
			messageVictoire.set_text("The player on the right won !!")
			ball.speed = 0

	elif ball.position.x > 651:
		paddleDroit.position = Vector2(620.0, 325)
		paddleGauche.position = Vector2(30.0, 325.0)
		ball.position = Vector2(325.0, 325.0)
		ball.direction = Vector2(1, -1)
		score_gauche += 1
		scoreGauche.text = str(score_gauche)
		if score_gauche == 5:
			messageVictoire.set_text("The player on the left won !!")
			ball.speed = 0.0

	if Input.is_physical_key_pressed(KEY_SPACE):
		paddleDroit.position = Vector2(620.0, 325)
		paddleGauche.position = Vector2(30.0, 325.0)
		messageVictoire.set_text("")
		score_droit = 0
		scoreDroit.text = str(score_droit)
		score_gauche = 0
		scoreGauche.text = str(score_gauche)
		ball.speed = 300.0
