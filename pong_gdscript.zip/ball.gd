extends CharacterBody2D

@export var speed := 300.0 # vitesse de déplacement de la balle
var direction := Vector2(1, -1) # direction de départ : droite + haut

func _physics_process(delta): # Godot appelle cette fonction en boucle pour mettre à jour le mouvement
	velocity = direction * speed # calcule le mouvement selon la direction et la vitesse
	move_and_slide() # déplace la balle et détecte les collisions

	if get_slide_collision_count() > 0: # vérifie si la balle a touché un objet
		var collision = get_slide_collision(0) # récupère la première collision
		var collider = collision.get_collider() # récupère l'objet touché

		if collider.name == "mur haut": # collision avec le mur haut 
			direction.y = abs(direction.y) # force la balle à repartir vers le bas

		elif collider.name == "mur bas": # collision avec le mur bas
			direction.y = -abs(direction.y) # force la balle à repartir vers le haut

		if collider.name == "paddle droite": # collision avec le paddle droit
			direction.x = -abs(direction.x) # force la balle à repartir vers la gauche
			if collision.get_normal().y > 0.0:
				direction.y = abs(direction.y)
			elif collision.get_normal().y < 0.0:
				direction.y = -abs(direction.y)

		elif collider.name == "paddle  gauche": # collision avec le paddle gauche
			direction.x = abs(direction.x) # force la balle à repartir vers la droite
			if collision.get_normal().y > 0.0:
				direction.y = abs(direction.y)
			elif collision.get_normal().y < 0.0:
				direction.y = -abs(direction.y)
